from flask import Flask, request, jsonify
import json
from chatbot import predict_class, get_response

app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status":"ok"})

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    if not data or 'message' not in data:
        return jsonify({"error":"Please send JSON with 'message' field"}), 400
    msg = data['message']
    ints = predict_class(msg)
    res = get_response(ints, json.load(open('data/intents.json')))
    return jsonify({"response": res, "intents": ints})

if __name__ == '__main__':
    app.run(port=5005, debug=True)