
# AI-Powered Customer Support Chatbot

This repository contains a simple AI-powered chatbot built with Python, TensorFlow, and NLTK.
It uses a bag-of-words + small neural network approach to classify user intents and reply with pre-defined responses.

## Contents
- `data/intents.json` — sample intent patterns and responses
- `train.py` — script to preprocess data and train the model
- `models/` — saved Keras model and metadata (created after running `train.py`)
- `chatbot.py` — CLI interface to the chatbot using the trained model
- `app.py` — Flask API exposing `/chat` for POST requests
- `requirements.txt` — Python package requirements

## Quickstart
1. Create a virtual environment and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate  # on Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Train the model:
   ```bash
   python train.py
   ```
3. Run the chatbot CLI:
   ```bash
   python chatbot.py
   ```
4. Run the Flask API:
   ```bash
   python app.py
   ```
