import numpy as np, random, json, pickle, os
from tensorflow.keras.models import load_model
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

ps = PorterStemmer()

MODEL_PATH = 'models/chatbot_model.h5'
WORDS_PATH = 'models/words.pkl'
CLASSES_PATH = 'models/classes.pkl'
INTENTS_PATH = 'data/intents.json'

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError("Model not found. Run train.py first to create models/chatbot_model.h5")

model = load_model(MODEL_PATH)
with open(WORDS_PATH, 'rb') as f:
    words = pickle.load(f)
with open(CLASSES_PATH, 'rb') as f:
    classes = pickle.load(f)
with open(INTENTS_PATH, 'r', encoding='utf-8') as f:
    intents = json.load(f)

def clean_up_sentence(sentence):
    sentence_words = word_tokenize(sentence)
    sentence_words = [ps.stem(w.lower()) for w in sentence_words if w.isalnum()]
    return sentence_words

def bag_of_words(sentence, words):
    sentence_words = clean_up_sentence(sentence)
    bag = [0]*len(words)
    for s in sentence_words:
        for i,w in enumerate(words):
            if w == s:
                bag[i] = 1
    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence, words)
    res = model.predict(np.array([bow]))[0]
    ERROR_THRESHOLD = 0.3
    results = [[i,r] for i,r in enumerate(res) if r>ERROR_THRESHOLD]
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({"intent": classes[r[0]], "probability": str(r[1])})
    return return_list

def get_response(ints, intents_json):
    if not ints:
        return "Sorry, I didn't understand that. Can you rephrase?"
    tag = ints[0]['intent']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if i['tag'] == tag:
            return random.choice(i['responses'])
    return "I am not sure how to help with that."

if __name__ == '__main__':
    print("Customer Support Chatbot (type 'quit' to exit)")
    while True:
        msg = input("You: ")
        if msg.lower() in ['quit','exit']:
            break
        ints = predict_class(msg)
        res = get_response(ints, intents)
        print("Bot:", res)